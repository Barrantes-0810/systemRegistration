#include "Course.h"

Course::Course()
{
	this->isAvaibleCourse = false;
}

Course::Course(string, int, string, int)
{
	this->courseName = "";
	this->courseCredits = 0;
	this->courseTeacher = "";
	this->courseCode = 0;
}

Course::~Course()
{
}

void Course::setCourseName(string)
{
	this->courseName = courseName;
}

void Course::setCourseCredits(int)
{
	this->courseCredits = courseCredits;
}

void Course::setCourseTeacher(string)
{
	this->courseTeacher = courseTeacher;
}

void Course::setCourseCode(int)
{
	this->courseCode = courseCode;
}

string Course::getCourseName()
{
	return this->courseName;
}

int Course::getCourseCredits()
{
	return this->courseCredits;
}

string Course::getCourseTeacher()
{
	return this->courseTeacher;
}

int Course::getCourseCode()
{
	return this->courseCode;
}

bool Course::getAvaibleCourse()
{
	return this->isAvaibleCourse;
}
